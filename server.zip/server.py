import tkinter as tk
import pyautogui
from PIL import Image
import keyboard
import cv2
import numpy as np
# Hàm test sẽ được chạy khi nhấn nút
import time 

from api import callapi_nhl 
from timbainhl import timlabai,timlabai2
from testtimmau  import xacdinhchatbai_nhl ,xacdinhchatbai_board ,xacdinh_text_rasie ,xacdinh_action ,xacdinh_action_stack ,tim_pot
import logging
logging.getLogger('ppocr').setLevel(logging.ERROR)
logging.getLogger('paddle').setLevel(logging.ERROR)
template_cb = cv2.imread('images/chuanbi.png')
template_cb = cv2.cvtColor(template_cb, cv2.COLOR_BGR2GRAY)
template_fold =cv2.imread('images/fold.png')
template_fold = cv2.cvtColor(template_fold, cv2.COLOR_BGR2GRAY)
template_check =cv2.imread('images/check.png')
template_check = cv2.cvtColor(template_check, cv2.COLOR_BGR2GRAY)
template_allin =cv2.imread('images/allin.png')
template_allin = cv2.cvtColor(template_allin, cv2.COLOR_BGR2GRAY)
template_raise =cv2.imread('images/raise.png')
template_raise = cv2.cvtColor(template_raise, cv2.COLOR_BGR2GRAY)
template_trong =cv2.imread('images/chotrong.png')
template_trong = cv2.cvtColor(template_trong, cv2.COLOR_BGR2GRAY)
template_chuyenban =cv2.imread('images/chuyenban.png')
template_chuyenban = cv2.cvtColor(template_chuyenban, cv2.COLOR_BGR2GRAY)

threshold = 0.8  # Ngưỡng khớp, giá trị từ 0 đến 1
loi = True
all_in_cac_vong_sau=False
chuyen_ban_thanh_cong=False
hanhdong_status=True
def chupanhmanhinh():
      screenshot = pyautogui.screenshot(region=(0, 0, 550, 950))
# Bước 2: Chuyển đổi ảnh chụp màn hình từ định dạng PIL sang định dạng mà OpenCV có thể xử lý
      screenshot = np.array(screenshot)
      screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
      return screenshot
def hanhdong(bai,chat,chat_board,action, check ,action_text ,songcon ,stack ):
     
     global hanhdong_status
     
     pot_hien_tai = tim_pot()

     result= callapi_nhl(bai,chat,chat_board,action ,pot_hien_tai ,action_text ,songcon ,stack)
     if hanhdong_status ==False:
          print('tu choi')
          return
    #  textmoi = "Nội dung mới"
     if result =="fold":
          if check:
               call()
          else: 
            fold_bai()
            if songcon >1:
               chuyen_ban()
               return
            # stack = "39 bb"
            number = ''.join(filter(str.isdigit, stack))  # Chỉ giữ ký tự số
            # print(number)  # Kết quả: "39"
            number =int(number)
            if number >50:
               chuyen_ban()
               return
         
     elif result == "call":
        
          call()
     elif result =="noaction":
          print("doi action nhe")
          time.sleep(3)
          fold_bai()
     elif result == "bet":
            raise_text =xacdinh_text_rasie()
            raise_text =raise_text.lower()

            if "all" in action:
                  call()
            else: 
                  
                  if "all" in raise_text:
                      pyautogui.click(450, 910) 
                  else:
                       bet()
                 
     elif result == "all":
           raise_text =xacdinh_text_rasie()
           raise_text =raise_text.lower()
           if "bb" in action:
                if "all" in raise_text:
                        pyautogui.click(450, 910) 
                else:
                        allin()
                  
           elif "check" in action:
                if "all" in raise_text:
                        pyautogui.click(450, 910) 
                else:
                        allin()
           elif "all" in action:
                    call()
           else:

                  fold_bai()
     else:
          if check:
               call()
          else:
               
               fold_bai()
          
     pyautogui.moveTo(800,825)
     label.config(text=f"tyle : {result}")
     root.update()
def fold_bai():
    pyautogui.click(100, 915)
def call():
    pyautogui.click(270, 910)
def bet():
    pyautogui.click(450, 910)
    time.sleep(0.8)
    pyautogui.click(305, 910)
    time.sleep(0.8)
    pyautogui.click(450, 910)

    # time.sleep(0.5)
    # pyautogui.click(450, 910)

def tinhsonguoitrong(screenshot):
    result3 =  cv2.matchTemplate(screenshot, template_trong, cv2.TM_CCOEFF_NORMED) 
    locations = np.where(result3 >= 0.65)
    print(len(locations[0]))
    h, w = template_trong.shape[:2]  # Kích thước của ảnh mẫu
    rects = []
    for pt in zip(*locations[::-1]):  # Đảo ngược tọa độ (x, y)
        rects.append([pt[0], pt[1], pt[0] + w, pt[1] + h])  # Tọa độ (x1, y1, x2, y2)

    # Lọc trùng lặp bằng Non-Maximum Suppression
    if len(rects) > 0:
        rects = np.array(rects)
        indices = cv2.dnn.NMSBoxes(rects.tolist(), [1] * len(rects), score_threshold=0.5, nms_threshold=0.5)
        count = len(indices)
    else:
        count = 0

    # In ra số lượng ảnh được tìm thấy
    return count
def chuyen_ban():
    global template_chuyenban
    pyautogui.click(43, 72)
    time.sleep(3)
    thanhcong=False
    screenshot = chupanhmanhinh()   
    result2 = cv2.matchTemplate(screenshot, template_chuyenban, cv2.TM_CCOEFF_NORMED)
    locations2 = np.where(result2 >= 0.9)
    if len(locations2[0]) > 0:  
        print('click vao vi tri chuyen ban')
        pyautogui.click(125, 400)
        
        pyautogui.moveTo(350,400)
        time.sleep(1)
       
        time.sleep(2)
        screenshot = chupanhmanhinh()   
        result2 = cv2.matchTemplate(screenshot, template_chuyenban, cv2.TM_CCOEFF_NORMED)
        locations2 = np.where(result2 >= 0.9)
        if len(locations2[0]) > 0:  
            print('van ban cu chuyen ban')  
            pyautogui.click(450, 400)
        else:
            print('da chuyen ban')  
            thanhcong=True 
            time.sleep(1.5)
            pyautogui.moveTo(350,400)
            time.sleep(1)
            pyautogui.mouseDown(button='left')
            time.sleep(1.5)
            pyautogui.move(0, -150)  # Di chuyển 0 đơn vị theo trục x và -200 đơn vị theo trục y (lên trên)
        
            # Thả chuột trái
            pyautogui.mouseUp(button='left')
            time.sleep(2)
            pyautogui.click(235, 758)
            time.sleep(3)
            pyautogui.click(470, 755)
            time.sleep(2)
            pyautogui.moveTo(350,400)
            time.sleep(1)
            pyautogui.mouseDown(button='left')
            time.sleep(1)
            pyautogui.move(0, 150)  # Di chuyển 0 đơn vị theo trục x và -200 đơn vị theo trục y (lên trên)
        
            # Thả chuột trái
            pyautogui.mouseUp(button='left')
            time.sleep(1)

            
    return thanhcong

    print('chuyen ban khac')
def allin_mot_nua():
    pyautogui.click(450, 910)
    time.sleep(0.5)
    pyautogui.moveTo(436,825)
    time.sleep(0.5)
    pyautogui.mouseDown(button='left')
    time.sleep(0.5)
    pyautogui.move(0, -150)  # Di chuyển 0 đơn vị theo trục x và -200 đơn vị theo trục y (lên trên)
   
    # Thả chuột trái
    pyautogui.mouseUp(button='left')
    time.sleep(0.5)
    pyautogui.click(450, 910)
    time.sleep(0.5)
    pyautogui.click(450, 910)
    #  print("songuoicon_lai ",songuoicon_lai)
def allin():
    pyautogui.click(450, 910)
    time.sleep(0.5)
    pyautogui.moveTo(436,825)
    time.sleep(0.5)
    pyautogui.mouseDown(button='left')
    time.sleep(0.5)
    pyautogui.move(0, -300)  # Di chuyển 0 đơn vị theo trục x và -200 đơn vị theo trục y (lên trên)
   
    # Thả chuột trái
    pyautogui.mouseUp(button='left')
    time.sleep(0.5)
    pyautogui.click(450, 910)
    time.sleep(0.5)
    pyautogui.click(450, 910)
    #  print("songuoicon_lai ",songuoicon_lai)
def exit_program():
    print("ESC được nhấn! Thoát chương trình.")
    global loi
    loi =False  # Dừng chương trình ngay lập tức
keyboard.add_hotkey('p', exit_program)
# keyboard.add_hotkey('f', fold_bai)
# keyboard.add_hotkey('c', call)
def auto():
      global hanhdong_status
      hanhdong_status=True
def tuchoi():
      global hanhdong_status
      hanhdong_status=False
keyboard.add_hotkey('a', auto)
keyboard.add_hotkey('t', chuyen_ban)


def test2():
     labia = timlabai()
     print(labia)
def test():
   
    stack="20 bb"
    
    du_lieu_stack = cv2.imread('anhstack.png')
    du_lieu_stack = cv2.cvtColor(du_lieu_stack, cv2.COLOR_BGR2GRAY)
    du_lieu_board = cv2.imread('baiboarrd.png')
    du_lieu_board = cv2.cvtColor(du_lieu_board, cv2.COLOR_BGR2GRAY)
  
    songcon =9
    list_la_bai =[]
    list_bai_board=[]
    chatlabai_board=[]
    chatlabai=[]
    print("bat dau.")
    kiemtra_la_bai=True
    du_lieu_anh_bai=cv2.imread('t5.png') 
    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
    global loi ,all_in_cac_vong_sau
    loi=True
    
    while loi:
        start_time = time.time()
      
        screenshot = chupanhmanhinh()   
        result2 = cv2.matchTemplate(screenshot, template_fold, cv2.TM_CCOEFF_NORMED)
        locations2 = np.where(result2 >= threshold)
        
        if len(locations2[0]) > 0:  
          
            # songuoicon_lai= songuoi(screenshot,template_songuoichoi)
            anh_bai_cu = cv2.matchTemplate(screenshot, du_lieu_anh_bai, cv2.TM_CCOEFF_NORMED)
            check = np.where(anh_bai_cu >= 0.95)         
            if len(check[0]) > 0:
                kiemtra_la_bai =False
            else:
                #   sang ván mới rồi
                 chatlabai_board=[]
                 kiemtra_la_bai =True
                 all_in_cac_vong_sau =False
            # if all_in_cac_vong_sau:
            #      allin()
            #      time.sleep(4)
            #      continue
            if  kiemtra_la_bai or len(chatlabai)!=2:
                du_lieu_anh_bai =  pyautogui.screenshot(region=(338, 772,80, 25)) # trong club pyautogui.screenshot(region=(188, 40, 42, 23)) #  pyautogui.screenshot(region=(338, 772,80, 25)) # pyautogui.screenshot(region=(338, 772,80, 25)) 
                du_lieu_anh_bai = np.array(du_lieu_anh_bai)
                chatlabai = xacdinhchatbai_nhl(du_lieu_anh_bai)
                chatlabai = [x for x in chatlabai if x != "none"]
            
            if kiemtra_la_bai or len(list_la_bai) ==0:
                
               
                du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)      
                list_la_bai = timlabai()
                stack = xacdinh_action_stack()
                songcon =tinhsonguoitrong(screenshot)
                if len(chatlabai) !=2:
                    du_lieu_anh_bai =  pyautogui.screenshot(region=(338, 772,80, 25)) # trong club pyautogui.screenshot(region=(188, 40, 42, 23)) #  pyautogui.screenshot(region=(338, 772,80, 25)) # pyautogui.screenshot(region=(338, 772,80, 25)) 
                    du_lieu_anh_bai = np.array(du_lieu_anh_bai)
                    chatlabai = xacdinhchatbai_nhl(du_lieu_anh_bai)
                    chatlabai = [x for x in chatlabai if x != "none"]
                    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
            check_board =  cv2.matchTemplate(screenshot,du_lieu_board,cv2.TM_CCOEFF_NORMED )
            locations4 = np.where(check_board >= 0.95)
            if len(locations4[0]) <=0:
               
                    du_lieu_board = pyautogui.screenshot(region=(125, 409,300, 26))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
                
                    du_lieu_board = np.array(du_lieu_board)
                    chatlabai_board = xacdinhchatbai_board(du_lieu_board,chatlabai_board)
                    chatlabai_board = [x for x in chatlabai_board if x != "none"]
                    du_lieu_board = cv2.cvtColor(du_lieu_board, cv2.COLOR_BGR2GRAY)
            
            
            action = xacdinh_action()
            action = action.lower()
            if len(chatlabai) !=2:
                 continue
            if "bb" in action:
                
                  hanhdong(list_la_bai,chatlabai,chatlabai_board,action,False ,False ,songcon ,stack )
            elif "check" in action:
                  hanhdong(list_la_bai,chatlabai,chatlabai_board,"check", True ,False,songcon ,stack )
            elif "all" in action:
                  stack = xacdinh_action_stack()
                  hanhdong(list_la_bai,chatlabai,chatlabai_board,stack ,False , True ,songcon ,stack)
                  
            else:
                #  lỗi fold bài
                  print('rong')
                  fold_bai()

            end_time = time.time()
            elapsed_time = end_time - start_time
# 188 40 230 62
            print(f"hanh dong2 : {elapsed_time:.4f} giây")  
            time.sleep(4)
            continue
        result3 = cv2.matchTemplate(screenshot, template_cb, cv2.TM_CCOEFF_NORMED) 
        locations3 = np.where(result3 >= threshold)
        if len(locations3[0]) > 0:      
            anh_bai_cu = cv2.matchTemplate(screenshot, du_lieu_anh_bai, cv2.TM_CCOEFF_NORMED)
            check = np.where(anh_bai_cu >= 0.95)
            if len(check[0]) > 0:
                kiemtra_la_bai =False
            else:
                 chatlabai_board=[]
                 kiemtra_la_bai =True
                 all_in_cac_vong_sau =False

            if  kiemtra_la_bai or len(chatlabai)!=2:
                du_lieu_anh_bai =  pyautogui.screenshot(region=(338, 772,80, 25)) # trong club pyautogui.screenshot(region=(188, 40, 42, 23)) #  pyautogui.screenshot(region=(338, 772,80, 25)) # pyautogui.screenshot(region=(338, 772,80, 25)) 
                du_lieu_anh_bai = np.array(du_lieu_anh_bai)
                chatlabai = xacdinhchatbai_nhl(du_lieu_anh_bai)
                chatlabai = [x for x in chatlabai if x != "none"]
                du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
       
            if kiemtra_la_bai or len(list_la_bai) ==0:
                if len(chatlabai)!=2:
                    du_lieu_anh_bai =pyautogui.screenshot(region=(338, 772,80, 25))  # pyautogui.screenshot(region=(188, 40, 42, 23))#  pyautogui.screenshot(region=(338, 772,80, 25))     #   pyautogui.screenshot(region=(338, 772,80, 25))        
                    du_lieu_anh_bai = np.array(du_lieu_anh_bai)

                    chatlabai = xacdinhchatbai_nhl(du_lieu_anh_bai)
                    chatlabai = [x for x in chatlabai if x != "none"]
                    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
                    
                list_la_bai = timlabai()
                stack = xacdinh_action_stack() 
                songcon =tinhsonguoitrong(screenshot)
            check_board =  cv2.matchTemplate(screenshot,du_lieu_board,cv2.TM_CCOEFF_NORMED )
            locations4 = np.where(check_board >= 0.95)
            if len(locations4[0]) <= 0:
                    du_lieu_board = pyautogui.screenshot(region=(125, 409,300, 26))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
                    du_lieu_board = np.array(du_lieu_board)
                    chatlabai_board = xacdinhchatbai_board(du_lieu_board , chatlabai_board)
                    chatlabai_board = [x for x in chatlabai_board if x != "none"]
                    du_lieu_board = cv2.cvtColor(du_lieu_board, cv2.COLOR_BGR2GRAY)

       
            end_time = time.time()
            elapsed_time = end_time - start_time

            print(f"hanh dong bai : {elapsed_time:.4f} giây")  
            time.sleep(1.5)
            continue      
        # time.sleep(4)
        # label.config(text=string)
      
        time.sleep(2.5)      
    print("out cu")   

# Tạo cửa sổ chính
root = tk.Tk()
root.title("Start Button Example")
root.geometry("300x700")
# 
# Tạo nhãn và trường nhập liệu
label2 = tk.Label(root, text="Nhập một số:")
label2.pack(pady=5)

entry = tk.Entry(root)
entry.pack(pady=5)
# Tạo nút Start và gán nó với hàm test
start_button = tk.Button(root, text="Start", command=test)
start_button.pack(pady=20)
label = tk.Label(root, text="")
label.pack(pady=10)
label.config(text="test thung")
# Chạy giao diện chính
root.mainloop()
