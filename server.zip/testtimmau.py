import cv2
import numpy as np
import time 
import pyautogui
import pytesseract
import easyocr
reader = easyocr.Reader(['en'])
from singleton_ocr import OCRSingleton

# # Lấy đối tượng OCR đã khởi tạo
ocr = OCRSingleton.get_instance()
# Đọc ảnh
# image = cv2.imread('thumau1.png')

# Chia ảnh thành 5 vùng chứa từng lá bài
# height, width, _ = image.shape
# card_width = width // 5  # Giả sử luôn có 5 lá bài
# cards = [image[:, i*card_width:(i+1)*card_width] for i in range(5)]

# Chuyển ảnh sang không gian màu HSV
def detect_suit(card):
    hsv_image = cv2.cvtColor(card, cv2.COLOR_BGR2HSV)
    
    # Định nghĩa dải màu cho từng chất bài (trong HSV)
    # Màu xanh dương cho chất rô
    # lower_blue = np.array([105, 180, 100])  # Giới hạn thấp hơn
    # upper_blue = np.array([125, 255, 255])  # Giới hạn cao hơn
    lower_blue = np.array([100, 150, 80])  # Hue thấp hơn
    upper_blue = np.array([130, 255, 255])  # Hue cao hơn

    # Màu đỏ cho chất cơ
    lower_red1 = np.array([0, 120, 70])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([170, 120, 70])
    upper_red2 = np.array([180, 255, 255])
    

    # Màu xanh lá cho chất tép
    lower_green = np.array([40, 100, 50])
    upper_green = np.array([80, 255, 255])

    # Màu đen cho chất bích (xấp xỉ bằng độ bão hòa và giá trị thấp)
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 50])

    # Tạo mặt nạ cho từng chất bài
    mask_blue = cv2.inRange(hsv_image, lower_blue, upper_blue)
    mask_red1 = cv2.inRange(hsv_image, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv_image, lower_red2, upper_red2)
    mask_red = mask_red1 | mask_red2
    mask_green = cv2.inRange(hsv_image, lower_green, upper_green)
    mask_black = cv2.inRange(hsv_image, lower_black, upper_black)

    # Kiểm tra mặt nạ nào có nhiều pixel nhất (để xác định chất)
    blue_count = cv2.countNonZero(mask_blue)
    red_count = cv2.countNonZero(mask_red)
    green_count = cv2.countNonZero(mask_green)
    black_count = cv2.countNonZero(mask_black)
    
    # Lưu kết quả vào dictionary để dễ so sánh
    counts = {
        "h": blue_count,
        "d": red_count,   # cơ  nhung thành rô
        "c": green_count,
        "s": black_count
    }

    # Kiểm tra giá trị cao nhất và lớn hơn 10
    max_suit = max(counts, key=counts.get)
    if counts[max_suit] > 0:
        # print(counts[max_suit])
        return max_suit
    else:
        # print(counts[max_suit])
        return "none"

# Phát hiện chất bài cho từng lá

# In ra thứ tự các chất

def xacdinhchatbai(image):
    # image = cv2.imread('mau2.png')

    height, width, _ = image.shape
    card_width = width // 5  # Giả sử luôn có 5 lá bài
    cards = [image[:, i*card_width:(i+1)*card_width] for i in range(5)]
    # for i, card in enumerate(cards):
    #     filename = f'anh{i+1}.png'  # Đặt tên file tương ứng với từng lá bài
    #     cv2.imwrite(filename, card)  # Lưu ảnh
    
    suits = [detect_suit(card) for card in cards]

    return suits
def detect_suit_board(card ,board,index):
    if index < len(board):
         return board[index]
    hsv_image = cv2.cvtColor(card, cv2.COLOR_BGR2HSV)
    
    # Định nghĩa dải màu cho từng chất bài (trong HSV)
    # Màu xanh dương cho chất rô
    lower_blue = np.array([105, 180, 100])  # Giới hạn thấp hơn
    upper_blue = np.array([125, 255, 255])  # Giới hạn cao hơn

    # Màu đỏ cho chất cơ
    lower_red1 = np.array([0, 120, 70])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([170, 120, 70])
    upper_red2 = np.array([180, 255, 255])

    # Màu xanh lá cho chất tép
    lower_green = np.array([40, 100, 50])
    upper_green = np.array([80, 255, 255])

    # Màu đen cho chất bích (xấp xỉ bằng độ bão hòa và giá trị thấp)
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 30])

    # Tạo mặt nạ cho từng chất bài
    mask_blue = cv2.inRange(hsv_image, lower_blue, upper_blue)
    mask_red1 = cv2.inRange(hsv_image, lower_red1, upper_red1)
    mask_red2 = cv2.inRange(hsv_image, lower_red2, upper_red2)
    mask_red = mask_red1 | mask_red2
    mask_green = cv2.inRange(hsv_image, lower_green, upper_green)
    mask_black = cv2.inRange(hsv_image, lower_black, upper_black)

    # Kiểm tra mặt nạ nào có nhiều pixel nhất (để xác định chất)
    blue_count = cv2.countNonZero(mask_blue)
    red_count = cv2.countNonZero(mask_red)
    green_count = cv2.countNonZero(mask_green)
    black_count = cv2.countNonZero(mask_black)

    # Lưu kết quả vào dictionary để dễ so sánh
    counts = {
        "h": blue_count,
        "d": red_count,
        "c": green_count,
        "s": black_count
    }

    # Kiểm tra giá trị cao nhất và lớn hơn 10
    max_suit = max(counts, key=counts.get)
    if counts[max_suit] > 0:
        gray = cv2.cvtColor(card, cv2.COLOR_BGR2GRAY)
        _, thresh = cv2.threshold(gray, 170, 255, cv2.THRESH_BINARY_INV)

# # # Phóng to ảnh để cải thiện độ phân giải
        rescaled_image = cv2.resize(thresh, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
        result = ocr.ocr(rescaled_image, cls=True)
        detected_words = ""
        # Hiển thị kết quả
        for line in result:
            if line is not None:
                    for word_info in line:
                        if word_info is not None:
                            card_string = word_info[1][0]
                            print('moi ',card_string)
                            detected_words =detected_words+card_string
        # Convert the image to grayscale (optional, for better OCR accuracy)
        # gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # OCR with Pytesseract
        # custom_config = r'--oem 3 --psm 7'
      
        # text = pytesseract.image_to_string(rescaled_image,config=custom_config)
        # cleaned_text = ''.join(text.split())
        if detected_words!="":
             return detected_words+ "_"+ max_suit
        _text=""
        result = reader.readtext(rescaled_image)
    # tex_call =""
        for (bbox, text, prob) in result:

               _text =_text+text
               print('a ',text)
        if _text == "":
            custom_config = r'--oem 3 --psm 10'
            text = pytesseract.image_to_string(rescaled_image,config=custom_config)
            cleaned_text = ''.join(text.split())
            _text =cleaned_text
            print("hh ",_text)
      
        return _text+ "_"+ max_suit
    else:
        # print(counts[max_suit])
        return "none"

def xacdinhchatbai_board(image ,board):
   
    # image = cv2.imread('mau2.png')
    height, width, _ = image.shape
    card_width = width // 5  # Giả sử luôn có 5 lá bài
    cards = [image[:, i*card_width+1:(i+1)*card_width -15] for i in range(5)]
    for i, card in enumerate(cards):
        filename = f'anh{i+1}.png'  # Đặt tên file tương ứng với từng lá bài
        cv2.imwrite(filename, card)  # Lưu ảnh
    
    suits = [detect_suit_board(card, board, index=i) for i, card in enumerate(cards)]
  
    return suits
def tim_pot():
    du_lieu_anh_bai = pyautogui.screenshot(region=(222, 333,140, 30))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
    # du_lieu_anh_bai.save("anhpot.png")  
    du_lieu_anh_bai = np.array(du_lieu_anh_bai)
    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
    result = reader.readtext(du_lieu_anh_bai)
    tex_call =""
    for (bbox, text, prob) in result:
        tex_call =tex_call+text
    return tex_call
def xacdinh_text_rasie():
    du_lieu_anh_bai = pyautogui.screenshot(region=(380, 889,150, 50))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
    # du_lieu_anh_bai.save("anhcall.png")  
    du_lieu_anh_bai = np.array(du_lieu_anh_bai)
    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
    result = reader.readtext(du_lieu_anh_bai)
    tex_call =""
    for (bbox, text, prob) in result:
        tex_call =tex_call+text
    return tex_call
def xacdinh_action():
    du_lieu_anh_bai = pyautogui.screenshot(region=(195, 889,150, 50))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
    # du_lieu_anh_bai.save("anhcall.png")  
    du_lieu_anh_bai = np.array(du_lieu_anh_bai)
    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
    result = reader.readtext(du_lieu_anh_bai)
    tex_call =""
    for (bbox, text, prob) in result:
        tex_call =tex_call+text
    return tex_call
def xacdinh_action_stack():
    du_lieu_anh_bai = pyautogui.screenshot(region=(231, 860,80, 20))   # 386 433  screenshot = pyautogui.screenshot(region=(305, 761,180, 35))   
    # du_lieu_anh_bai.save("anhcall.png")  
    du_lieu_anh_bai = np.array(du_lieu_anh_bai)
    du_lieu_anh_bai = cv2.cvtColor(du_lieu_anh_bai, cv2.COLOR_BGR2GRAY)
    result = reader.readtext(du_lieu_anh_bai)
    tex_call =""
    for (bbox, text, prob) in result:
        tex_call =tex_call+text
    return tex_call

def xacdinhchatbai_nhl(image):
        # image = cv2.imread('mau2.png')
    # du_lieu_anh_bai =  pyautogui.screenshot(region=(338, 772,80, 25))     #   pyautogui.screenshot(region=(305, 761,180, 65))        
    # image = np.array(du_lieu_anh_bai)
    height, width, _ = image.shape
    card_width = width // 2  # Giả sử luôn có 5 lá bài
    cards = [image[:, i*card_width:(i+1)*card_width] for i in range(2)]
    # for i, card in enumerate(cards):
    #     filename = f'anh{i+1}.png'  # Đặt tên file tương ứng với từng lá bài
    #     cv2.imwrite(filename, card)  # Lưu ảnh
    
    suits = [detect_suit(card) for card in cards]
    print(suits)
    return suits
